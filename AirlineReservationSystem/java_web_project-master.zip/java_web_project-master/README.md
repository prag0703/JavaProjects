# Java Web Project

## Introduction 
This is an airline reservation system which users can search one-way or round trip flights. They can select direct, 1 stop or 2 stop flights. They can specify taking off time and landing time. They can also sort tickets by price, flight time and total time. Finally they can buy one or more tickets.

## Demo 
* http://youtu.be/c4T9FIXFxas

## Technologies used
* Java EE, Multithreading, DOM, XML, Servlet, JSP, JavaScript, Html, Tomcat, Singleton design pattern    

## Credits
* Worcester Polytechnic Institute (WPI) Design of Software Systems (Professor Nelson)
* I am responsible for whole backend Java classes.
* Naihui Wang and Yu Tian are responsible for frontend part. 
* Database server is setup by Professor, and we access the database by Http post and get. 

